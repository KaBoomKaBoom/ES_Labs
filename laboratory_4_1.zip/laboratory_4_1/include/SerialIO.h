#ifndef SERIAL_IO_H
#define SERIAL_IO_H

#include <Arduino.h>
#include <stdio.h>

void serialInit();


#endif 